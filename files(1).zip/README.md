# Klasseromplassering (nettversjon)

Statisk nettside – ingen server, ingen installasjon. Alt lagrar seg i
nettlesaren (localStorage) på eininga du brukar.

## Køyre lokalt
Opne `index.html` i ein nettlesar, eller (for å unngå enkelte
nettlesarbegrensingar på lokale filer):
```
python3 -m http.server 8000
```
og gå til `http://localhost:8000`.

## Hoste på nett
Last opp dei fem filene (`index.html`, `style.css`, `core.js`, `i18n.js`,
`app.js`) til t.d. GitHub Pages, Netlify eller Cloudflare Pages. Ingen
byggjesteg, ingen bakgrunnstenester.

## Viktig om lagring
Data (klassar, elevar, historikk, innstillingar) lagrar seg i
nettlesaren sin localStorage – bunde til denne eininga/nettlesaren.
Bytter du eining, bruk **Last ned fil** / **Last opp fil** (Klasse-fana)
for å flytte ein klasse over. Ingen elevdata blir sende til nokon
server.

## Struktur
- `index.html` – sidestruktur, fire faner
- `style.css` – tema (CSS-variablar), utsjånad
- `core.js` – datamodell, algoritme, localStorage
- `i18n.js` – tekstar (nynorsk/bokmål/engelsk)
- `app.js` – all appstyring, teikning, drag, dialogar

## Funksjonar
Same funksjonalitet som skrivebordsversjonen (bordgrupper, svarteliste,
kjønnsvekting, historikk, soner, vend visning), pluss:
- Fire faner: Klasse, Klasserom, Plassering, Innstillingar
- **Rom skilt frå klasse**: eit rom (bordgrupper/soner) kan brukast av
  fleire klassar, og du kan byte rom for ei klasse når som helst
  (Klasserom-fana). Slettar du eit rom som er i bruk, får dei råka
  klassane automatisk eit nytt, tomt rom.
- Nye rom kan autofyllast med parbord ut frå elevtalet
- Slå saman/skil ut bordgrupper (Ctrl+klikk fleire plassar)
- Fleire klassar, med standardklasse
- Språkbyte: nynorsk / bokmål / engelsk
- Fullstendige tema (lys/mørk/Catppuccin), fargeval, bakgrunnsbilete,
  uskarpheit/gjennomsikt på pultar, skalering av grensesnitt/tekst,
  manuell pultstorleik
- Endre storleik på/minimer elevliste- og historikkpanelet
- PNG-eksport med gjeldande tema/bakgrunnsbilete, og valfri
  dato/tid/veke/klassenamn på biletet
- Nye rom kan tilpassast eksakt til elevtalet ("Lag rutenett automatisk"
  → "Fyll ut basert på X elevar")
- Har romet fleire plassar enn elevar, fyller tilfeldig plassering dei
  fremste (næraste tavla) først - resten står tomme lengst bak
- Touch-vennleg: hald inne ein pult for å markere han (som Ctrl+klikk).
  Med minst éin pult markert, held vanlege trykk fram med å markere/
  avmarkere fleire
- Slå saman bordgrupper tek omsyn til korleis pultane faktisk står:
  over kvarandre gir fleire rader, ved sida av kvarandre gir fleire
  kolonnar
- Høgreklikk ein enkelt pult for å skilje han ut av bordgruppa si,
  utan å måtte merke han først
- Kvar klasse kan bruke fleire rom - plassering, lås og historikk vert
  no bevart per rom når du byter, i staden for å gå tapt
- Endringar i romoppsettet (bordgrupper, soner, snu visning) er no eit
  utkast til du uttrykkeleg lagrar eller forkastar dei, med ei tydeleg
  varsellinje så lenge det er ulagra endringar. Elevplassering og
  lås/opning av plassar vert framleis lagra umiddelbart som før
- Eksportert bilete (PNG) viser no berre tavle, plassar og namn - ingen
  soner, lås eller svarteliste-/gjentakingsvarsel
- Førehandsvis biletet direkte i appen før nedlasting (Plassering →
  "Førehandsvis bilete"), med ei eiga snu-vising uavhengig av romet sitt
  eige oppsett - fin for å vise digitalt på skjerm under plassbytte
- "Auto-merk framme/bak" (Klasserom-fana) merkjer automatisk rada
  næraste tavla som framme og rada lengst unna som bak, ut frå faktisk
  geometri - fungerer på alle romoppsett, ikkje berre rutenett
- Slå saman bordgrupper tek omsyn til korleis pultane faktisk står:
  over kvarandre gir fleire rader, ved sida av kvarandre gir fleire
  kolonnar
- Verktøylinja i Klasserom er delt i tydelege grupper: rom-styring,
  automatiske handlingar, og handlingar for valde plassar. Ein eigen
  "☰ Meny for valde"-knapp opnar same meny som høgreklikk, for
  touch-skjermar. "Merk ingen" tømer utvalet raskt
- Endre storleik-panela (elevar/historikk) i Plassering kan minimerast
  og alltid utvidast att - knappen peikar i retninga han utvidar mot
- Sikkerheitskopi: last ned all data (klassar+rom) øvst i Innstillingar,
  og last opp att seinare med valfri utveljing av kva klassar/rom som
  skal importerast
- Tilbakemelding-knapp (e-post) og ein vernande "Slett all lokal
  lagring"-knapp (krev at du skriv eit stadfestingsord) nedst i
  Innstillingar
- Bla fram og tilbake i tidlegare lagra plasseringar for heile klassen
  (Plassering → "Bla i tidlegare plasseringar"), med eiga snu-vising og
  moglegheit til å gjenopprette ei tidlegare plassering
- Heatmap over kor ein elev har sete tidlegare (grønt=lenge sidan,
  raudt=nyleg), global av/på-brytar øvst i historikk-panelet - skru på
  éin gong og bla fritt mellom elevar utan å krysse av på nytt. Held
  fram å stemme sjølv om romet vert endra eller pultstorleiken endrar
  seg sidan
- Kjønnspanelet er kompakt med radioknappar (–/J/G/A) i staden for
  nedtrekksmenyar, og tek mykje mindre plass
- Svarteliste har no eit fullt oversyn over alle reglar for klassen
  ved sida av panelet, med rask fjern-knapp per regel
- Ko-fi-knapp i Innstillingar (under tilbakemelding) for dei som vil
  støtte prosjektet
